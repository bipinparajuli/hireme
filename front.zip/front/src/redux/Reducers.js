

// Auth Reducers
// import Login from "./Login/Reducer";
// import Register from "./Register/Reducer";
// import ChangePassword from "./ChangePassword/Reducer";

import Jobs from "./Jobs/Reducer"


// import MainLayout from "./MainLayout/Reducer";

export default {
  // Common Reducers
  Jobs
  // MainLayout,
  // PropertyEdit,
  // Auth Reducers
  // Login,
  // Register,
  // ChangePassword,
}