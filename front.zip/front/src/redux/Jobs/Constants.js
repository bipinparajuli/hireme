export const JOBS_SUCCESS = 'Jobs/JOBS_SUCCESS';
export const JOBS_FAILURE = 'Jobs/JOBS_FAILURE';
